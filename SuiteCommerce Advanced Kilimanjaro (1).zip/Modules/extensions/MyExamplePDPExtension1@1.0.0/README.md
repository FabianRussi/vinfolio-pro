A simple Frontend PDPComponent example which shows:
	How to replace a default view with a custom one
	How to remove a view
	How to do some validation before the PDP is rendered and render a custom error view if the validation fails 
	How to select some item's options after the PDP was rendered

#Installation

In distro.json:

 * make sure this module is included in the "modules" array

 * Include the following in the "dependencies" array of the shopping application: 

    "MyExamplePDPExtension1"
	
* Include the following in the sass dependencies array of the shopping application: 

    "MyExamplePDPExtension1"