A simple Frontend PDPComponent example which shows:
	How to add several custom views in the same placeholder
	How to use the childViewIndex to define the order in which the views are being rendered

#Installation

In distro.json:

 * make sure this module is included in the "modules" array

 * Include the following in the "dependencies" array of the shopping application: 

    "MyExamplePDPExtension1"
	
 * Include the following in the sass dependencies array of the shopping application: 

    "MyExamplePDPExtension1"